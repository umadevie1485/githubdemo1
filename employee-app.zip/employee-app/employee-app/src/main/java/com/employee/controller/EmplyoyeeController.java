package com.employee.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.employee.model.Employee;
import com.employee.service.EmployeeService;

import antlr.collections.List;

@RestController
public class EmplyoyeeController {
	
	@Autowired
	private EmployeeService empSer;
	
	public Optional<Employee> get(int id) {
		return empSer.get(id);
	}
	
	public List<Employee> get() {
	return empSer.getAll();
	}
	
	
	
	
	

}
