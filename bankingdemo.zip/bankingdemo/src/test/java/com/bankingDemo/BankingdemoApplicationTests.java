package com.bankingDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
