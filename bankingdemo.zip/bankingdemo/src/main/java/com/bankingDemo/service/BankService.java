package com.bankingDemo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingDemo.medel.Banking;
import com.bankingDemo.repository.BankRepository;

@Service
public class BankService {
	
@Autowired
public BankRepository bankrepo;

public String save(Banking bnk) {
    return bankrepo.save(bnk).toString();
    
  
    }
	
}



