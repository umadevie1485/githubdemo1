package com.bankingDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bankingDemo.medel.Banking;
import com.bankingDemo.service.BankService;

@Controller
public class BankController {
	
	@Autowired
	private BankService bnksrv; 
	
	@GetMapping("/")
	public String save(Banking bank) {
		return "bank";
	}
	

	
	@PostMapping("/fundTransfer")
	
	public String save(int acno,String branchName,int ifsc,float amount) {
		Banking bnk=new Banking();
		bnk.setAcno(acno);
		bnk.setbranchName(branchName);
		bnk.setIfsc(ifsc);
		bnk.setAmount(amount);
		System.out.println("account number:"+acno);
		System.out.println("account number:"+branchName);
		
		 bnksrv.save(bnk);
		 return "moneytransfer";
			
		}
		

	@PostMapping("/fund")

	public String savebank(Banking bank) {
		return "success";

	}
	

	@PostMapping("/fund2")
    @ResponseBody
	public String savebank2(@RequestBody Banking bank) {
		return "successful";
	}
	
	

}
