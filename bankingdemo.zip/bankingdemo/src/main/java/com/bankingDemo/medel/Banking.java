package com.bankingDemo.medel;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Banking {
	@Id
	@GeneratedValue
	private int id;
	private int acno;
	private String branchName;
	private int ifsc;
	private float amount;
	public Banking() {
		super();
		
	}
	public Banking(int acno, String branchName, int ifsc, float amount) {
		super();
		this.acno = acno;
		this.branchName = branchName;
		this.ifsc = ifsc;
		this.amount = amount;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public String getbranchName() {
		return branchName;
	}
	public void setbranchName(String branchName) {
		this.branchName = branchName;
	}
	public int getIfsc() {
		return ifsc;
	}
	public void setIfsc(int ifsc) {
		this.ifsc = ifsc;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Banking [acno=" + acno + ", branchName=" + branchName + ", ifsc=" + ifsc + ", amount=" + amount + "]";
	}

}
