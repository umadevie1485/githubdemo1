package com.ticketbook.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;


import com.ticketbook.model.TicketGenerate;
import com.ticketbook.service.TicketGenerateService;

@Controller
public class TicketGenerateController {
	@Autowired
	private TicketGenerateService  tktsrv;
	
	@PostMapping("/save")
	@ResponseBody
	public TicketGenerate Save(@RequestBody @Valid TicketGenerate tkt) {
   return tktsrv.Save(tkt);
   
   public String ticketBooking(String "fname",String "lname",String "tNO,String source,String destination,String amount) {
	   
   }
   
   
}
	
	
	
	
	
	
}