package com.ticketbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayappApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwayappApplication.class, args);
		System.out.println("welcome");
	}

}
