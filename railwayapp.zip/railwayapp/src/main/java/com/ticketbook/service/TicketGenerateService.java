package com.ticketbook.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ticketbook.model.TicketGenerate;
import com.ticketbook.repository.TicketGenerateRepository;

@Service
public class TicketGenerateService {
	@Autowired
	private TicketGenerateRepository tktrepo;
	
	public TicketGenerate Save(TicketGenerate tk) {
		return tktrepo.save(tk);
		
	}
	

}
