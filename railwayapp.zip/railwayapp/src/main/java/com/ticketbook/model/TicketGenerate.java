package com.ticketbook.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class TicketGenerate {  
	@Id
	@GeneratedValue
	private int id;
	private int tNO;
	private String fname;
	private String lname;
	private String pnrNo;
	private String source;
	private String destination;
	private String ph;
	private String email;
	private String status;
	private float amount;
	public TicketGenerate() {
		super();
		
	}
	public TicketGenerate(int id, int tNO, String fname, String lname, String pnrNo, String source, String destination,
			String ph, String email, String status, float amount) {
		super();
		this.id = id;
		this.tNO = tNO;
		this.fname = fname;
		this.lname = lname;
		this.pnrNo = pnrNo;
		this.source = source;
		this.destination = destination;
		this.ph = ph;
		this.email = email;
		this.status = status;
		this.amount = amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int gettNO() {
		return tNO;
	}
	public void settNO(int tNO) {
		this.tNO = tNO;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getPh() {
		return ph;
	}
	public void setPh(String ph) {
		this.ph = ph;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TicketGenerate [id=" + id + ", tNO=" + tNO + ", fname=" + fname + ", lname=" + lname + ", pnrNo="
				+ pnrNo + ", source=" + source + ", destination=" + destination + ", ph=" + ph + ", email=" + email
				+ ", status=" + status + ", amount=" + amount + "]";
	}
	

	

}
